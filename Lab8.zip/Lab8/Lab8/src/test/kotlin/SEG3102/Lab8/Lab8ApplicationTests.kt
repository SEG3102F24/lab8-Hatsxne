package SEG3102.Lab8

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class Lab8ApplicationTests {

	@Test
	fun contextLoads() {
	}

}
