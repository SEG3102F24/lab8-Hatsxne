package SEG3102.Lab8

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class Lab8Application

fun main(args: Array<String>) {
	runApplication<Lab8Application>(*args)
}
