package SEG3102.Lab8.resolvers

import SEG3102.Lab8.entity.Employee
import SEG3102.Lab8.repository.EmployeeRepository
import org.springframework.graphql.data.method.annotation.Argument
import org.springframework.graphql.data.method.annotation.MutationMapping
import org.springframework.graphql.data.method.annotation.QueryMapping
import org.springframework.stereotype.Controller

@Controller
class EmployeeResolver(private val employeeRepository: EmployeeRepository) {

    @QueryMapping
    fun allEmployees(): List<Employee> = employeeRepository.findAll()

    @QueryMapping
    fun employeeById(@Argument id: String): Employee? =
        employeeRepository.findById(id).orElse(null)

    @MutationMapping
    fun addEmployee(@Argument input: CreateEmployeeInput): Employee {
        val employee = Employee(
            firstName = input.firstName,
            lastName = input.lastName,
            position = input.position,
            email = input.email
        )
        return employeeRepository.save(employee)
    }

    @MutationMapping
    fun updateEmployee(@Argument id: String, @Argument input: UpdateEmployeeInput): Employee {
        val employee = employeeRepository.findById(id).orElseThrow { RuntimeException("Employee not found") }
        input.firstName?.let { employee.firstName = it }
        input.lastName?.let { employee.lastName = it }
        input.position?.let { employee.position = it }
        input.email?.let { employee.email = it }
        return employeeRepository.save(employee)
    }
}
